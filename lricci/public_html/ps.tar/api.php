<?php
$arr = array(
	'query' => $_GET['query']
);
echo json_encode($arr);